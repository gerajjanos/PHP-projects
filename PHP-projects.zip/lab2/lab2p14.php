<?php 
$nr = 3;

$parSauImpar = (($nr%2 == 0 ? "nr par" : "nr impar"));
echo $parSauImpar;


?>