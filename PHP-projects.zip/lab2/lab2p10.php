<?php 
$sir = "www.domeniu.com";
$substing = substr($sir,4);
echo $substing;
?>