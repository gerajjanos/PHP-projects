<?php 
$sir = "WDWWLWWWLDDWDLL";
	$char = substr($sir,-3); 
	echo $char;
?>