<?php
$text = "\"Good morning, Dave,\" said HAL.";
echo "<p><i>" . $text . "</i></p>";
?>