<?php 
$sir = "0000000www.dome000niu.com";
$trimmed = str_replace("0","", $sir);
echo $trimmed;
?>