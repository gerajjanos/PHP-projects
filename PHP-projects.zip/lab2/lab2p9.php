<?php 
$sir = "abcdefghij";
$sir2 = "wadjd dawdaw dawd";
$upper=strtoupper($sir);
echo $upper . "<br/>";
$lower=strtolower($upper);
echo $lower . "<br/>";
$primulMare=ucfirst($sir);
echo $primulMare . "<br/>";
$d =ucwords($sir2, " ");
echo $d . "<br/>";

?>