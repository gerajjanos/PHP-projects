<?php 
$sir = "<i>Tomorrow I'll learn PHP global variable.<i><br/>" . "This is a bad command: del c:\*.*";
echo $sir;
?>