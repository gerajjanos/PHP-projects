<?php 
$sir = "WDWWLWWWLDDWDLL";
$search = "L";
	$pozitie = strpos($sir, $search);
	$char = substr($sir,$pozitie + 1, 1); 
	echo $char;
?>