<?php 
$v = "\"PHP is fun\"";
echo "Sirul are " . strlen($v) . " caractere.";
?>