<?php 
$currentFolder = getcwd();
echo $currentFolder;
?>