<?php 
$pi2=number_format(pi(),2);
$radius =3;
$aria=$pi2*$radius*$radius;
echo $aria;
?>