<?php 
$sir = "WDWWLWWWLDDWDLL";
$search = "WWW";
	$pozitie = strpos($sir, $search);
	$char = substr($sir,$pozitie + 3, 1); 
	echo $char;
?>