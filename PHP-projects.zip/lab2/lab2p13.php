<?php 
$nr = 3;
if($nr%2 == 0){
	echo "Numarul dat este par!";
	}
	else {
		echo "Numarul dat este impar!";
	}

?>