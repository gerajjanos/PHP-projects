<?php 

/*function fibonacci($n,$first = 0,$second = 1)
{
    $fib = [$first,$second];
    for($i=1;$i<$n;$i++)
    {
        $fib[] = $fib[$i]+$fib[$i-1];
    }
    return $fib;
}
echo "<pre>";
print_r(fibonacci(50));
*/
	
	$num1 = 0; 
    $num2 = 1; 
	$n = 20;
    $i = 0;
	echo "Numerele Fibonacchi pana la " . $n . " sunt " . $num1 . ", " . $num2;
    while ( $i<= $n){  
        $num3 = $num2 + $num1; 
        $num1 = $num2; 
        $num2 = $num3; 
      
	   if ($num3 > $n){
		   break;
	   }
	   echo ", " . $num3;
    } 
  
?>