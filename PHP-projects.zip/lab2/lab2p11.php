<?php 
$sir = "0000000www.domeniu.com";
$trimmed = ltrim($sir,"0");
echo $trimmed;
?>