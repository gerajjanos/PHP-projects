<?php 
$h=55;
$c=(5/9)*($h-32);
$c=round($c, 1);
echo $c;

echo "<br/>";

//sau cum era data rezolvarea

function temperatura($tfahrenheit)
{
	$tcelsius=(5/9)*($tfahrenheit-32);
	return $tcelsius;
}
$tempF = 55;
echo "Temperatura Fahrenheit: " . $tempF . "<br/>";
$tempC = temperatura($tempF);
$tempC = round($tempC, 1);
echo "Tempteratura Celsius: " . $tempC . "<br/>";



?>