<?php 
$cuvant = "Sebes";
$cuvant = strtolower($cuvant);
$cuvantRev = strrev($cuvant);
$pal = "E palindrom!";
$nepal = "Nu e palindrom!";
$palindrom = ($cuvant == $cuvantRev? $pal : $nepal);
echo $palindrom;

?>