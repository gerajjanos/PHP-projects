<?php 
$nr = 12345;
$i=0;
function getsum ($nr){
	$sum=0;	
	while($nr!=0){
		$sum+=$nr%10;
		$nr = $nr/10;
	}
	return $sum;
}
$res = getsum ($nr);
echo $res;
?>