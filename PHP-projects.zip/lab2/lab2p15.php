<?php 

$nr = 1;
$nr2 = 4;
$nr3 = 2;
$max = $nr;

$max = ($max>$nr2 ? $max : ($nr2>$nr3 ? $nr2 : $nr3));
echo $max;
?>