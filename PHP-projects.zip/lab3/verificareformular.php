<?php
$numeErr=$prenumeErr=$userErr=$mailErr=$stareCErr=$pwdErr=$repwdErr=$sexErr="";
$nume=$prenume=$user=$mail=$stareC=$pwd=$repwd=$sex="";
$error=0;

if($_SERVER["REQUEST_METHOD"]=="POST"){
	if(empty($_POST["nume"])){
		$numeErr = "Name is required!";
		$error=1;
	} else {
		$nume=test_input($_POST["nume"]);
		if(!preg_match("/^[a-zA-Z]*$/", $nume)){
			$numeErr = "Only letters and white space allowed!";
		}
	}
	if(empty($_POST["prenume"])){
		$prenumeErr = "Prenume is required!";
		$error=1;
	} else {
		$prenume=test_input($_POST["prenume"]);
		if(!preg_match("/^[a-zA-Z]*$/", $prenume)){
			$prenumeErr = "Only letters and white space allowed!";
		}
	}
	if(empty($_POST["user"])){
		$userErr = "Username is required!";
		$error=1;
	} else {
		$user=test_input($_POST["user"]);
		if(!preg_match("/^[a-zA-Z0-9]*$/", $user)){
			$userErr = "Only letters and white space allowed!";
		}
	}
	if(empty($_POST["mail"])){
		$mail = "E-mail is required!";
		$error=1;
	} else {
		$mail=test_input($_POST["mail"]);
		if(!filter_var($mail,FILTER_VALIDATE_EMAIL)){
			$mailErr = "Invalid E-mail format!";
		}
	}
	if(empty($_POST["pwd"])){
		$pwdErr = "Password is required!";
		$error=1;
	} else {
		$pwd=test_input($_POST["pwd"]);
		if(!preg_match("/^[a-zA-Z0-9]*$/", $pwd)){
			$pwdErr = "Only letters and white space allowed!";
		}
	}
	if(empty($_POST["repwd"])){
		$repwdErr = "Re-type password is required!";
		$error=1;
	} else {
		$repwd=test_input($_POST["repwd"]);
		if(!preg_match("/^[a-zA-Z0-9]*$/", $repwd)){
			$repwdErr = "Only letters and white space allowed!";
		}
	}
	if(empty($_POST["sex"])){
		$sexErr="Sex is required!";
		$error=1;
	} else {
		$sex =test_input($_POST["sex"]);
	}
}
Function test_input($data){
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}
?>