<?php
$editFormAction=$_SERVER['PHP_SELF'];
if(isset($_SERVER['QUERY_STRING'])) 
{
$editFormAction .="?".htmlentities($_SERVER['QUERY_STRING']);
}
if((isset($_POST["MM_insert"]))&&($_POST['MM_insert'] == "formular1")) {
	
$un = $_POST['user'];
$pass = $_POST['password'];
if(($un=="user") && ($pass=="password")) {
	echo "Logare cu success!!!";
} else {
	echo "Username sau password gresit!!!";
}


exit();
}

?>

<form action ="<?php echo $editFormAction; ?>"  
	method="POST" name="formular1" target="_self" id="formular1">
	
<p> 
	User <input name="user" type="text" id="user" size="80"/>  
</p>
<p> 
	Password <input name="password" type="text" id="password" size="15"/>  
</p>
<p> 
	<input name="continuare" type="submit" id="continuare" value = "Continuare"/>
 </p>

<input	type = "hidden" name = "MM_insert" value = "formular1">
</form>