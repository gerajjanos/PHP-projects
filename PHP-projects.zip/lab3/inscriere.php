<html><head>
	<style>.error {color:#FF0000;}</style>
</head><body>
<?php
$editFormAction=$_SERVER['PHP_SELF'];
if(isset($_SERVER['QUERY_STRING'])) 
{
$editFormAction .="?".htmlentities($_SERVER['QUERY_STRING']);
}
if((isset($_POST["MM_insert"]))&&($_POST['MM_insert'] == "login")) {
}
include 'verificareformular.php';
?>



<form action ="<?php echo $_SERVER['PHP_SELF'];?>"  
	method="POST" name="login" target="_self" id="login">
<p> 
	Nume <input name="nume" type="text" id="nume" size="80" value="<?php echo $nume; ?>" required /> 
		<span class="error">*<?php echo $numeErr;?></span>
</p>

<p> 
	Prenume <input name="prenume" type="text" id="prenume" size="80" value="<?php echo $prenume; ?>" required /> 
		<span class="error">*<?php echo $prenumeErr;?></span>
</p>	

<p> 
	Username <input name="user" type="text" id="user" size="80" value="<?php echo $user; ?>" required />
		<span class="error">*<?php echo $userErr;?></span>
</p>

<p> 
	E-mail <input name="mail" type="text" id="mail" size="80" value="<?php echo $mail; ?>" required />  
		<span class="error">*<?php echo $mailErr;?></span>
</p>

<p> 
	<p>Sex:</p>
  <div>
    <input type="radio" id="F"
     name="sex" value="F" checked>
    <label for="choice">F</label>

    <input type="radio" id="M"
     name="sex" value="M">
    <label for="choice">M</label>
  </div>
</p>

	<p>Stare civila:</p>
  <div>
    <input type="checkbox" id="stareC"
     name="stareC" value="Casatorit" >
    <label for="choice">Casatorit</label>
  </div>

<p> 
	Password <input name="pwd" type="password" id="pwd" size="15" value="<?php echo $nume; ?>" required /> 
		<span class="error">*<?php echo $pwd;?></span>	
</p>

<p> 
	Re-type Password <input name="repwd" type="password" id="repwd" size="15" value="<?php echo $nume; ?>" required />
		<span class="error">*<?php echo $repwd;?></span>
</p>

<p> 
	<input name="submit" type="submit" id="submit" value = "SUBMIT"/>
 </p>

<input	type = "hidden" name = "MM_insert" value = "login">
</form>
<?php 

if ($error==0)
{
require_once 'config.php';

$db=mysqli_connect($host,$usernamesql,$parolasql,$db_name) or die("Could not connect!");

mysqli_select_db($db, $db_name);

$utilizator = test_input($_POST["user"]);

$query = "SELECT * FROM $tbl_name WHERE username= '$utilizator'";

$result = mysqli_query($db,$query);

$count=mysqli_num_rows($result);
	if($count==1)
	{
		$usernameerr="Utilizator existent. Alegeti alt utilizator";
        $eroare=1;
	}
	$query="SELECT * FROM $tbl_name WHERE email= '$mail'";
	$num=mysqli_num_rows($result);
    if($num==1)
    {
        $emailerr="Adresa de e-mail existent. Alegeti alta adresa";
        $eroare=1;
    }
}
printf("Result set has %d rows.\n",$result);
if($count==1){
	$usernameerr="Utilizatorul deja exista!";
	printf("Utilizatorul exista deja!");
} else {
	require_once 'config.php';
	$db=mysqli_connect($host,$usernamesql,$parolasql,$db_name) or die("Could not connect!");
	mysqli_select_db($db, $db_name);
	$query = "SELECT MAX(id) AS max FROM $tbl_name";
	$result=mysqli_query($db, $query);
	$result2=mysqli_fetch_array($result);
	$idnew=$result2['max']+1;
	$parola1=test_input($_POST["pwd"]);
	$parola1=md5($parola1);
	if ($starecivila1="on")
            {
              $starecivila1=1;
            }
            else
            {
              $starecivila1=0;
            }
	$query="INSERT INTO $tbl_name (id, username, parola, sex, starecivila, nume, prenume, 
	email) VALUES ('$idnew', '$user', '$pwd', '$sex', '$stareC',
	'$nume', '$prenume', '$mail')";
	$result=mysqli_query($db, $query);
	header("Location: login.php");
	
}
$result = mysqli_num_rows($result);

?>
</body></html>




















