<?php 
echo basename("www.example.com/publix.html/index.php");

?>