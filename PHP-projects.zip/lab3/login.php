<?php
$editFormAction=$_SERVER['PHP_SELF'];
if(isset($_SERVER['QUERY_STRING'])) 
{
$editFormAction .="?".htmlentities($_SERVER['QUERY_STRING']);
}
if((isset($_POST["MM_insert"]))&&($_POST['MM_insert'] == "login")) {
	
}
require_once 'config.php';

?>



<form action ="<?php "user.php" ?>"  
	method="POST" name="login" target="_self" id="login">
	
<p> 
	Username <input name="user" type="text" id="user" size="80"/>  
</p>
<p> 
	Password <input name="password" type="text" id="password" size="15"/>  
</p>
<p> 
	<p>ORDER BY NAME:</p>
  <div>
    <input type="radio" id="yes"
     name="ordine" value="Ascendent" checked>
    <label for="choice1">Yes</label>

    <input type="radio" id="no"
     name="ordine" value="Descendent">
    <label for="choice2">No</label>
  </div>
</p>
<p>
	Date: <input name="date" type="date" id="date" value="date">
</p>
<p> 
	<p>Sex:</p>
  <div>
    <input type="radio" id="F"
     name="sex" value="F" checked>
    <label for="choice">F</label>

    <input type="radio" id="M"
     name="sex" value="M">
    <label for="choice">M</label>
  </div>
</p>
<p> 
	<p>Married:</p>
  <div>
    <input type="radio" id="YES"
     name="merried" value="YES" checked>
    <label for="choice">YES</label>

    <input type="radio" id="NO"
     name="merried" value="NO">
    <label for="choice">NO</label>
  </div>
</p>




<p> 
	<input name="submit" type="submit" id="submit" value = "SUBMIT"/>
 </p>

<input	type = "hidden" name = "MM_insert" value = "login">
</form>


