<?php 

$host="localhost";
$usernamesql="root";
$parolasql="";
$db_name="userapp";
$tbl_name="utilizatori";
?>