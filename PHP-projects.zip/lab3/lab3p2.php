<?php 

$username = explode("@", "janos.geraj@gmail.com");
$user = $username[0];
echo $user;




?>