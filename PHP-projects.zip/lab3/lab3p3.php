<?php
$editFormAction=$_SERVER['PHP_SELF'];
if(isset($_SERVER['QUERY_STRING'])) 
{
$editFormAction .="?".htmlentities($_SERVER['QUERY_STRING']);
}
if((isset($_POST["MM_insert"]))&&($_POST['MM_insert'] == "formular1")) {
	//require("config.php");
	
$sir2 = $_POST['sir1'];
echo "Sir original: ". $sir2;
echo "<br><br>";
echo "Lungime sir: ". strlen($sir2);
echo "<br><br>";
echo "Sirul inversat: ". strrev($sir2);
echo "<br><br>";
echo "Sirul cu litere mici: ". strtoupper($sir2);
echo "<br><br>";
echo "Sirul cu litere mari: ". strtolower($sir2);
echo "<br><br>";
echo "<br><br>";
echo "<br><br>";
echo "<a href='lab3p3.php' target = '_self'> Introduceti alt sir: </a>";


}

?>

<form action ="<?php echo $editFormAction; ?>"  
	method="POST" name="formular1" target="_self" id="formular1">
	
<p> 
	<input name="sir1" type="text" id="sir1" size="80"/>  
</p>
<p> 
	<input name="continuare" type="submit" id="continuare" value = "Continuare"/>
 </p>

<input	type = "hidden" name = "MM_insert" value = "formular1">
</form>