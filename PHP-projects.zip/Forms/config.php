<?php
$host="localhost";
$usernamesql="root";
$passwordsql="";
$db_name="userapp";
$tbl_name="Utilizatori";
$max_file_size = "504500";
$file_dir = "poze/";
?>
